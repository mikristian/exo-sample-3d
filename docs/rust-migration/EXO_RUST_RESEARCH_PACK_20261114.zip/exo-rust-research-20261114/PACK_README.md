# EXO Rust research pack (source and documentation only)

EXO public Git source baseline: 985bc9a8e5031a9fa02666a44390802aff8e04ce
This offline archive includes the prioritized 41-system task board, Rust-code-percent dashboards, technical migration plan, source accounting, reproducible audit script and five public historical reports.
Read `research/README.md` and `research/METHODOLOGY.md` first.
Upstream ClothCraft research and task claims are referenced by URL, not duplicated upstream code or nonpublic state.
No executable app, CLO3D media, personal computer paths, credentials or user project files are included.
Code percentages are source-language share, not feature completion.
