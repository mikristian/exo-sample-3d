# EXO Rust + ClothCraft migration planning pack

Prepared 2026-11-15 against EXO GitHub `f7d007d2cbddad179f4272437af7e29189e15ee9`. **Planning documents only, not a completed Rust migration.**

Start with `EXO_REACT_RUST_CLOTHCRAFT_TWO_PHASE_PLAN_20261115.md`: Stage A keeps React while moving existing backend behavior to Rust+ClothCraft; Stage B replaces the UI section by section.

`EXO_FULL_RUST_41_SYSTEM_STAFFING_20261115.md` records the complete 41-system staffing, AI-agent assignment estimates and one-month scenarios. The 41-system CSV begins with `NOT_AUDITED` states because a live button audit is outstanding. `BUTTON_PARITY_LEDGER_TEMPLATE.csv` provides the required columns.

Included public reference plans and six-size tee QA are pinned to source. Physical fit still fails. `MANIFEST.json` has content digests. No code executables, private CLO assets, project files or credentials are included.
